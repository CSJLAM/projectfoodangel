import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ShowAttendPage } from './show-attend';

@NgModule({
  declarations: [
    ShowAttendPage,
  ],
  imports: [
    IonicPageModule.forChild(ShowAttendPage),
  ],
})
export class ShowAttendPageModule {}
