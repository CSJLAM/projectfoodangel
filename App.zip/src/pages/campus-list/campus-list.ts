import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-campus-list',
  templateUrl: 'campus-list.html'
})
export class CampusListPage {

  constructor(public navCtrl: NavController) {
  }
  
}
